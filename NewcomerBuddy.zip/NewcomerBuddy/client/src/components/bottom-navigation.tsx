import { Link, useLocation } from "wouter";
import { Home, Languages, Book, Clock, Users } from "lucide-react";

export default function BottomNavigation() {
  const [location] = useLocation();

  const navItems = [
    { path: "/", icon: Home, label: "Home" },
    { path: "/translate", icon: Languages, label: "Translate" },
    { path: "/dictionary", icon: Book, label: "Dictionary" },
    { path: "/history", icon: Clock, label: "History" },
    { path: "/community", icon: Users, label: "Community" },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 px-4 py-2 z-50">
      <div className="flex items-center justify-around max-w-md mx-auto">
        {navItems.map(({ path, icon: Icon, label }) => {
          const isActive = location === path;
          
          return (
            <Link key={path} href={path}>
              <div className={`flex flex-col items-center space-y-1 py-1 px-2 rounded-lg transition-colors duration-200 ${
                isActive 
                  ? 'text-ukraine-blue' 
                  : 'text-gray-500 hover:text-gray-700'
              }`}>
                <Icon className={`h-5 w-5 ${isActive ? 'text-ukraine-blue' : ''}`} />
                <span className={`text-xs font-medium ${isActive ? 'text-ukraine-blue' : ''}`}>
                  {label}
                </span>
              </div>
            </Link>
          );
        })}
      </div>
    </nav>
  );
}