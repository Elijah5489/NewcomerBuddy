import { useState, useCallback } from "react";
import { Button } from "@/components/ui/button";
import { useSpeech } from "@/hooks/use-speech";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Mic, Square } from "lucide-react";

interface VoiceRecorderProps {
  onTranslation: (ukrainian: string, english: string) => void;
}

export default function VoiceRecorder({ onTranslation }: VoiceRecorderProps) {
  const [isRecording, setIsRecording] = useState(false);
  const [currentLanguage, setCurrentLanguage] = useState<'uk' | 'en'>('en');
  const { toast } = useToast();

  const translateMutation = useMutation({
    mutationFn: async (data: { text: string; from: string; to: string }) => {
      const response = await apiRequest("POST", "/api/translate", data);
      return await response.json();
    },
    onSuccess: (data, variables) => {
      const originalText = variables.text;
      const translatedText = data.translatedText;
      
      if (variables.to === 'uk') {
        onTranslation(translatedText, originalText);
      } else {
        onTranslation(originalText, translatedText);
      }
    },
    onError: () => {
      toast({
        title: "Translation failed",
        description: "Please try again.",
        variant: "destructive",
      });
    },
  });

  const { 
    isListening, 
    transcript, 
    startListening, 
    stopListening, 
    browserSupportsSpeechRecognition 
  } = useSpeech({
    language: currentLanguage === 'uk' ? 'uk-UA' : 'en-US',
    onResult: (finalTranscript: string) => {
      if (finalTranscript.trim()) {
        translateMutation.mutate({
          text: finalTranscript,
          from: currentLanguage,
          to: currentLanguage === 'uk' ? 'en' : 'uk'
        });
      }
      setIsRecording(false);
    },
    onError: (error: any) => {
      console.error('Speech recognition error:', error);
      toast({
        title: "Voice recognition failed",
        description: "Please try again or check your microphone.",
        variant: "destructive",
      });
      setIsRecording(false);
    }
  });

  const handleStartRecording = (language: 'uk' | 'en') => {
    if (!browserSupportsSpeechRecognition) {
      toast({
        title: "Speech recognition not supported",
        description: "Your browser doesn't support voice recognition.",
        variant: "destructive",
      });
      return;
    }

    setCurrentLanguage(language);
    setIsRecording(true);
    startListening();
  };

  const handleStopRecording = () => {
    setIsRecording(false);
    stopListening();
  };

  if (!browserSupportsSpeechRecognition) {
    return (
      <div className="text-center py-4">
        <p className="text-sm text-gray-500 mb-4">
          Voice recognition is not supported in your browser.
        </p>
        <p className="text-xs text-gray-400">
          Try using Chrome, Safari, or Edge for the best experience.
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {/* Voice Animation Display */}
      <div className="bg-gray-50 rounded-lg p-4 text-center min-h-[80px] flex flex-col justify-center">
        {isRecording ? (
          <div className="space-y-2">
            <div className="voice-waves flex justify-center space-x-1">
              <span className="voice-wave"></span>
              <span className="voice-wave"></span>
              <span className="voice-wave"></span>
              <span className="voice-wave"></span>
              <span className="voice-wave"></span>
            </div>
            <p className="text-sm text-ukraine-blue font-medium">
              Listening in {currentLanguage === 'uk' ? 'Ukrainian' : 'English'}...
            </p>
            {transcript && (
              <p className="text-xs text-gray-600 mt-2">"{transcript}"</p>
            )}
          </div>
        ) : translateMutation.isPending ? (
          <div className="space-y-2">
            <div className="w-6 h-6 border-2 border-ukraine-blue border-t-transparent rounded-full animate-spin mx-auto"></div>
            <p className="text-sm text-ukraine-blue">Translating...</p>
          </div>
        ) : (
          <p className="text-sm text-gray-500">Tap and hold to speak</p>
        )}
      </div>

      {/* Recording Buttons */}
      <div className="grid grid-cols-2 gap-3">
        <Button
          className="gradient-ukraine text-white py-3 px-4 rounded-lg font-medium text-sm shadow-md hover:shadow-lg transition-all duration-200"
          onMouseDown={() => handleStartRecording('uk')}
          onMouseUp={handleStopRecording}
          onTouchStart={() => handleStartRecording('uk')}
          onTouchEnd={handleStopRecording}
          disabled={isRecording && currentLanguage !== 'uk'}
        >
          {isRecording && currentLanguage === 'uk' ? (
            <Square className="mr-2 h-4 w-4" />
          ) : (
            <Mic className="mr-2 h-4 w-4" />
          )}
          Ukrainian
        </Button>
        
        <Button
          className="bg-gray-100 text-gray-700 py-3 px-4 rounded-lg font-medium text-sm hover:bg-gray-200 transition-all duration-200"
          onMouseDown={() => handleStartRecording('en')}
          onMouseUp={handleStopRecording}
          onTouchStart={() => handleStartRecording('en')}
          onTouchEnd={handleStopRecording}
          disabled={isRecording && currentLanguage !== 'en'}
        >
          {isRecording && currentLanguage === 'en' ? (
            <Square className="mr-2 h-4 w-4" />
          ) : (
            <Mic className="mr-2 h-4 w-4" />
          )}
          English
        </Button>
      </div>
    </div>
  );
}