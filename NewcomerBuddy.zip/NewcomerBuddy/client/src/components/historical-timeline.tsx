import { HistoricalEvent } from "@shared/schema";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Clock, AlertTriangle, Users, Crown, Landmark } from "lucide-react";

interface HistoricalTimelineProps {
  events: HistoricalEvent[];
}

export default function HistoricalTimeline({ events }: HistoricalTimelineProps) {
  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'Pioneer Settlement': return <Users className="h-4 w-4 text-white" />;
      case 'Mass Immigration': return <Users className="h-4 w-4 text-white" />;
      case 'Dark Chapter': return <AlertTriangle className="h-4 w-4 text-white" />;
      case 'Political Representation': return <Crown className="h-4 w-4 text-white" />;
      case 'Religious': return <Landmark className="h-4 w-4 text-white" />;
      default: return <Clock className="h-4 w-4 text-white" />;
    }
  };

  const getCategoryColor = (category: string) => {
    switch (category) {
      case 'Pioneer Settlement': return 'bg-blue-500';
      case 'Mass Immigration': return 'bg-green-500';
      case 'Dark Chapter': return 'bg-red-600';
      case 'Political Representation': return 'bg-purple-500';
      case 'Religious': return 'bg-amber-500';
      default: return 'bg-gray-500';
    }
  };

  const getCategoryBadgeColor = (category: string) => {
    switch (category) {
      case 'Pioneer Settlement': return 'bg-blue-100 text-blue-700';
      case 'Mass Immigration': return 'bg-green-100 text-green-700';
      case 'Dark Chapter': return 'bg-red-100 text-red-700';
      case 'Political Representation': return 'bg-purple-100 text-purple-700';
      case 'Religious': return 'bg-amber-100 text-amber-700';
      default: return 'bg-gray-100 text-gray-700';
    }
  };

  if (events.length === 0) {
    return (
      <Card>
        <CardContent className="p-4 text-center">
          <p className="text-gray-500">No historical events to display</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="card-shadow overflow-hidden">
      <CardContent className="p-4">
        <div className="timeline-line relative">
          {events.map((event, index) => (
            <div key={event.id} className="flex mb-8 relative last:mb-4">
              {/* Timeline Icon */}
              <div 
                className={`
                  w-10 h-10 rounded-full flex items-center justify-center z-10 flex-shrink-0
                  ${getCategoryColor(event.category)} shadow-lg
                `}
              >
                {getCategoryIcon(event.category)}
              </div>

              {/* Event Content */}
              <div className="ml-4 flex-1">
                <div className="bg-white border border-gray-100 rounded-lg p-4 shadow-sm">
                  {/* Year Badge */}
                  <div className="flex items-center justify-between mb-2">
                    <Badge className="gradient-ukraine text-white font-bold">
                      {event.year}
                    </Badge>
                    <Badge className={`text-xs ${getCategoryBadgeColor(event.category)}`}>
                      {event.category}
                    </Badge>
                  </div>

                  {/* Title */}
                  <h3 className="font-serif font-bold text-gray-900 mb-2 text-lg">
                    {event.title}
                  </h3>

                  {/* Description */}
                  <p className="text-sm text-gray-700 leading-relaxed mb-3">
                    {event.description}
                  </p>

                  {/* Importance Indicator */}
                  {(event.importance || 0) > 3 && (
                    <div className="flex items-center justify-end">
                      <Badge variant="outline" className="text-xs text-ukraine-blue border-ukraine-blue">
                        Key Event
                      </Badge>
                    </div>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Timeline Summary */}
        <div className="mt-6 pt-4 border-t border-gray-100">
          <div className="text-center space-y-2">
            <p className="text-sm font-medium text-gray-900">
              {events.length} events spanning {Math.max(...events.map(e => e.year)) - Math.min(...events.map(e => e.year))} years
            </p>
            <p className="text-xs text-gray-600">
              From {Math.min(...events.map(e => e.year))} to {Math.max(...events.map(e => e.year))}
            </p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}