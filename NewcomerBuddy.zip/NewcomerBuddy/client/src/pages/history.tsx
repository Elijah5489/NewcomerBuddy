import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useQuery } from "@tanstack/react-query";
import { HistoricalEvent } from "@shared/schema";
import HistoricalTimeline from "@/components/historical-timeline";
import { Landmark, Clock, Users, AlertTriangle, Crown } from "lucide-react";
import { useState } from "react";

export default function History() {
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);

  const { data: historicalEvents = [] } = useQuery<HistoricalEvent[]>({
    queryKey: ["/api/history"],
  });

  const categories = Array.from(new Set(historicalEvents.map(event => event.category)));
  
  const filteredEvents = selectedCategory 
    ? historicalEvents.filter(event => event.category === selectedCategory)
    : historicalEvents;

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'Pioneer Settlement': return <Users className="h-4 w-4" />;
      case 'Mass Immigration': return <Users className="h-4 w-4" />;
      case 'Dark Chapter': return <AlertTriangle className="h-4 w-4" />;
      case 'Political Representation': return <Crown className="h-4 w-4" />;
      case 'Religious': return <Landmark className="h-4 w-4" />;
      default: return <Clock className="h-4 w-4" />;
    }
  };

  const getCategoryColor = (category: string) => {
    switch (category) {
      case 'Pioneer Settlement': return 'bg-blue-100 text-blue-700';
      case 'Mass Immigration': return 'bg-green-100 text-green-700';
      case 'Dark Chapter': return 'bg-red-100 text-red-700';
      case 'Political Representation': return 'bg-purple-100 text-purple-700';
      case 'Religious': return 'bg-amber-100 text-amber-700';
      default: return 'bg-gray-100 text-gray-700';
    }
  };

  const keyStatistics = [
    { label: "Years of History", value: "130+" },
    { label: "Major Events", value: historicalEvents.length.toString() },
    { label: "First Settlement", value: "1891" },
    { label: "Peak Immigration", value: "1896-1914" }
  ];

  return (
    <div className="pb-20">
      {/* Header */}
      <header className="gradient-ukraine text-white shadow-lg sticky top-0 z-50">
        <div className="max-w-md mx-auto px-4 py-4">
          <div className="text-center">
            <Landmark className="mx-auto text-ukraine-yellow text-3xl mb-2" />
            <h1 className="font-serif font-bold text-xl">From Galicia to the Prairies</h1>
            <p className="text-ukraine-light text-sm">130+ Years of Ukrainian Manitoba</p>
          </div>
        </div>
      </header>

      <main className="max-w-md mx-auto p-4 space-y-6">
        
        {/* Key Statistics */}
        <Card className="card-shadow">
          <CardContent className="p-4">
            <div className="grid grid-cols-2 gap-4">
              {keyStatistics.map((stat, index) => (
                <div key={index} className="text-center">
                  <p className="text-2xl font-bold text-ukraine-blue font-serif">{stat.value}</p>
                  <p className="text-sm text-gray-600">{stat.label}</p>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Category Filters */}
        <Card className="card-shadow">
          <CardContent className="p-4">
            <h3 className="font-serif font-semibold text-gray-900 mb-3">Filter by Period</h3>
            <div className="space-y-2">
              <Button
                variant={selectedCategory === null ? "default" : "outline"}
                onClick={() => setSelectedCategory(null)}
                className={selectedCategory === null ? "gradient-ukraine text-white w-full justify-start" : "w-full justify-start"}
              >
                <Clock className="mr-2 h-4 w-4" />
                All Periods
              </Button>
              
              {categories.map((category) => (
                <Button
                  key={category}
                  variant={selectedCategory === category ? "default" : "outline"}
                  onClick={() => setSelectedCategory(category)}
                  className={`w-full justify-start ${
                    selectedCategory === category ? "gradient-ukraine text-white" : ""
                  }`}
                >
                  {getCategoryIcon(category)}
                  <span className="ml-2">{category}</span>
                </Button>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Introduction */}
        <Card className="card-shadow">
          <CardContent className="p-4 bg-gradient-to-r from-ukraine-light/20 to-blue-50">
            <div className="space-y-3">
              <h2 className="font-serif font-bold text-xl text-gray-900">Our Ukrainian Heritage</h2>
              <p className="text-gray-700 text-sm leading-relaxed">
                The story of Ukrainian settlement in Manitoba spans over 130 years, from the first pioneers 
                who arrived in 1891 to today's vibrant Ukrainian-Canadian community. This timeline captures 
                the triumphs, challenges, and enduring spirit of our people.
              </p>
              <div className="flex items-center space-x-2">
                <Badge className="bg-ukraine-blue text-white">
                  {filteredEvents.length} Events
                </Badge>
                {selectedCategory && (
                  <Badge className={getCategoryColor(selectedCategory)}>
                    {selectedCategory}
                  </Badge>
                )}
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Historical Timeline */}
        <HistoricalTimeline events={filteredEvents} />

        {/* Additional Resources */}
        <Card className="card-shadow">
          <CardContent className="p-4">
            <h3 className="font-serif font-semibold text-gray-900 mb-3">Learn More</h3>
            <div className="space-y-3">
              <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                <div>
                  <p className="font-medium text-gray-900 text-sm">Manitoba Archives</p>
                  <p className="text-xs text-gray-600">Historical documents and photos</p>
                </div>
                <Button variant="outline" size="sm">
                  Visit
                </Button>
              </div>
              
              <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                <div>
                  <p className="font-medium text-gray-900 text-sm">Oseredok Centre</p>
                  <p className="text-xs text-gray-600">Ukrainian cultural museum</p>
                </div>
                <Button variant="outline" size="sm">
                  Visit
                </Button>
              </div>

              <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                <div>
                  <p className="font-medium text-gray-900 text-sm">Internment Recognition</p>
                  <p className="text-xs text-gray-600">WWI internment operations history</p>
                </div>
                <Button variant="outline" size="sm">
                  Learn
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Heritage Quote */}
        <Card className="card-shadow">
          <CardContent className="p-4 bg-gradient-to-r from-ukraine-blue/5 to-ukraine-yellow/5">
            <blockquote className="text-center space-y-2">
              <p className="text-gray-700 italic font-serif">
                "From the fields of Galicia to the prairies of Manitoba, our ancestors carried 
                dreams of freedom, prosperity, and cultural preservation that continue to flourish today."
              </p>
              <footer className="text-sm text-gray-500">
                — Ukrainian Manitoba Heritage
              </footer>
            </blockquote>
          </CardContent>
        </Card>
      </main>
    </div>
  );
}
