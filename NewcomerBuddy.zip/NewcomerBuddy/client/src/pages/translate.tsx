import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { useMutation, useQuery } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Translation } from "@shared/schema";
import VoiceRecorder from "@/components/voice-recorder";
import { 
  Languages, 
  ArrowUpDown, 
  Copy, 
  Heart, 
  History,
  Volume2,
  Keyboard
} from "lucide-react";

export default function Translate() {
  const [sourceText, setSourceText] = useState("");
  const [translatedText, setTranslatedText] = useState("");
  const [sourceLanguage, setSourceLanguage] = useState("en");
  const [targetLanguage, setTargetLanguage] = useState("uk");
  const [useVoice, setUseVoice] = useState(true);
  const { toast } = useToast();

  const { data: recentTranslations = [] } = useQuery<Translation[]>({
    queryKey: ["/api/translations"],
  });

  const translateMutation = useMutation({
    mutationFn: async (data: { text: string; from: string; to: string }) => {
      const response = await apiRequest("POST", "/api/translate", data);
      return await response.json();
    },
    onSuccess: (data) => {
      setTranslatedText(data.translatedText);
      // Save translation
      saveTranslationMutation.mutate({
        ukrainianText: targetLanguage === 'uk' ? data.translatedText : sourceText,
        englishText: targetLanguage === 'en' ? data.translatedText : sourceText,
        isFavorite: false
      });
    },
    onError: () => {
      toast({
        title: "Translation failed",
        description: "Please try again.",
        variant: "destructive",
      });
    },
  });

  const saveTranslationMutation = useMutation({
    mutationFn: async (data: { ukrainianText: string; englishText: string; isFavorite: boolean }) => {
      const response = await apiRequest("POST", "/api/translations", data);
      return await response.json();
    },
  });

  const handleTranslate = () => {
    if (!sourceText.trim()) return;
    
    translateMutation.mutate({
      text: sourceText,
      from: sourceLanguage,
      to: targetLanguage
    });
  };

  const handleVoiceTranslation = (ukrainian: string, english: string) => {
    setSourceText(sourceLanguage === 'uk' ? ukrainian : english);
    setTranslatedText(targetLanguage === 'uk' ? ukrainian : english);
    
    saveTranslationMutation.mutate({
      ukrainianText: ukrainian,
      englishText: english,
      isFavorite: false
    });
  };

  const swapLanguages = () => {
    setSourceLanguage(targetLanguage);
    setTargetLanguage(sourceLanguage);
    setSourceText(translatedText);
    setTranslatedText(sourceText);
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    toast({
      title: "Copied to clipboard",
      description: "Text has been copied successfully.",
    });
  };

  const playPronunciation = (text: string, lang: string) => {
    if ('speechSynthesis' in window) {
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.lang = lang === 'uk' ? 'uk-UA' : 'en-US';
      speechSynthesis.speak(utterance);
    }
  };

  return (
    <div className="pb-20">
      {/* Header */}
      <header className="gradient-ukraine text-white shadow-lg sticky top-0 z-50">
        <div className="max-w-md mx-auto px-4 py-4">
          <div className="text-center">
            <Languages className="mx-auto text-ukraine-yellow text-3xl mb-2" />
            <h1 className="font-serif font-bold text-xl">Speak & Translate</h1>
            <p className="text-ukraine-light text-sm">Ukrainian ↔ English Translation</p>
          </div>
        </div>
      </header>

      <main className="max-w-md mx-auto p-4 space-y-6">
        
        {/* Translation Method Toggle */}
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-center space-x-4">
              <Button
                variant={useVoice ? "default" : "outline"}
                onClick={() => setUseVoice(true)}
                className={useVoice ? "gradient-ukraine text-white" : ""}
              >
                <Languages className="mr-2 h-4 w-4" />
                Voice
              </Button>
              <Button
                variant={!useVoice ? "default" : "outline"}
                onClick={() => setUseVoice(false)}
                className={!useVoice ? "gradient-ukraine text-white" : ""}
              >
                <Keyboard className="mr-2 h-4 w-4" />
                Text
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Voice Translation */}
        {useVoice && (
          <Card>
            <CardHeader>
              <CardTitle className="text-center font-serif">Voice Translation</CardTitle>
            </CardHeader>
            <CardContent>
              <VoiceRecorder onTranslation={handleVoiceTranslation} />
            </CardContent>
          </Card>
        )}

        {/* Text Translation */}
        {!useVoice && (
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <span className="text-sm font-medium">
                    {sourceLanguage === 'uk' ? 'Ukrainian' : 'English'}
                  </span>
                </div>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={swapLanguages}
                  className="text-ukraine-blue hover:text-ukraine-deep"
                >
                  <ArrowUpDown className="h-4 w-4" />
                </Button>
                <div className="flex items-center space-x-2">
                  <span className="text-sm font-medium">
                    {targetLanguage === 'uk' ? 'Ukrainian' : 'English'}
                  </span>
                </div>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Textarea
                  value={sourceText}
                  onChange={(e) => setSourceText(e.target.value)}
                  placeholder={`Type in ${sourceLanguage === 'uk' ? 'Ukrainian' : 'English'}...`}
                  className="min-h-[100px] resize-none"
                />
              </div>
              
              <Button 
                onClick={handleTranslate} 
                disabled={!sourceText.trim() || translateMutation.isPending}
                className="w-full gradient-ukraine text-white hover:shadow-md"
              >
                {translateMutation.isPending ? "Translating..." : "Translate"}
              </Button>

              {translatedText && (
                <div className="bg-ukraine-light/20 rounded-lg p-4">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm font-medium text-gray-600">
                      {targetLanguage === 'uk' ? 'Ukrainian' : 'English'}
                    </span>
                    <div className="flex space-x-2">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => playPronunciation(translatedText, targetLanguage)}
                        className="text-ukraine-blue hover:text-ukraine-deep"
                      >
                        <Volume2 className="h-4 w-4" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => copyToClipboard(translatedText)}
                        className="text-ukraine-blue hover:text-ukraine-deep"
                      >
                        <Copy className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                  <p className="text-gray-900">{translatedText}</p>
                </div>
              )}
            </CardContent>
          </Card>
        )}

        {/* Recent Translations */}
        {recentTranslations.length > 0 && (
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center font-serif">
                <History className="mr-2 h-5 w-5 text-ukraine-blue" />
                Recent Translations
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {recentTranslations.slice(0, 5).map((translation) => (
                  <div key={translation.id} className="border border-gray-100 rounded-lg p-3">
                    <div className="flex items-start justify-between">
                      <div className="flex-1 space-y-1">
                        <p className="text-sm text-gray-600">UA: {translation.ukrainianText}</p>
                        <p className="text-sm text-gray-900">EN: {translation.englishText}</p>
                      </div>
                      <div className="flex space-x-1 ml-2">
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => copyToClipboard(translation.englishText)}
                          className="text-gray-400 hover:text-ukraine-blue"
                        >
                          <Copy className="h-3 w-3" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          className="text-gray-400 hover:text-red-500"
                        >
                          <Heart className="h-3 w-3" />
                        </Button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}
      </main>
    </div>
  );
}
