import { Link } from "wouter";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useQuery } from "@tanstack/react-query";
import { HistoricalEvent, CommunityResource } from "@shared/schema";
import { 
  Languages, 
  BookOpen, 
  GraduationCap, 
  Landmark, 
  Users,
  Mic,
  Volume2
} from "lucide-react";
import VoiceRecorder from "@/components/voice-recorder";
import { useState } from "react";

export default function Home() {
  const [translationResult, setTranslationResult] = useState<{
    ukrainian: string;
    english: string;
  } | null>(null);

  const { data: historicalEvents = [] } = useQuery<HistoricalEvent[]>({
    queryKey: ["/api/history"],
  });

  const { data: upcomingEvents = [] } = useQuery<CommunityResource[]>({
    queryKey: ["/api/community/events"],
  });

  const handleTranslation = (ukrainian: string, english: string) => {
    setTranslationResult({ ukrainian, english });
  };

  const playPronunciation = (text: string, lang: 'uk' | 'en') => {
    if ('speechSynthesis' in window) {
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.lang = lang === 'uk' ? 'uk-UA' : 'en-US';
      speechSynthesis.speak(utterance);
    }
  };

  const featuredEvents = historicalEvents.slice(0, 3);

  return (
    <div className="pb-20">
      {/* Header */}
      <header className="gradient-ukraine text-white shadow-lg sticky top-0 z-50">
        <div className="max-w-md mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <Languages className="text-ukraine-yellow text-2xl" />
              <div>
                <h1 className="font-serif font-bold text-lg">Ukrainian Manitoba</h1>
                <p className="text-ukraine-light text-xs">Your Community Companion</p>
              </div>
            </div>
            <Button variant="outline" size="sm" className="bg-ukraine-yellow text-ukraine-blue border-ukraine-yellow hover:bg-ukraine-light">
              <Users className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </header>

      <main className="max-w-md mx-auto">
        
        {/* Quick Translation */}
        <section className="p-4 animate-fade-in">
          <Card className="card-shadow">
            <CardContent className="p-6">
              <div className="text-center mb-4">
                <div className="inline-flex items-center justify-center w-16 h-16 gradient-yellow rounded-full mb-3">
                  <Mic className="text-white text-2xl" />
                </div>
                <h2 className="font-serif font-semibold text-xl text-gray-900 mb-2">Speak & Translate</h2>
                <p className="text-gray-600 text-sm">Ukrainian ↔ English instantly</p>
              </div>

              <VoiceRecorder onTranslation={handleTranslation} />

              {/* Translation Results */}
              {translationResult && (
                <div className="mt-4 space-y-3">
                  <div className="bg-ukraine-light/20 rounded-lg p-3">
                    <p className="text-sm text-gray-600 mb-1">Ukrainian:</p>
                    <p className="font-medium">{translationResult.ukrainian}</p>
                  </div>
                  <div className="bg-blue-50 rounded-lg p-3">
                    <p className="text-sm text-gray-600 mb-1">English:</p>
                    <div className="flex items-center justify-between">
                      <p className="font-medium flex-1">{translationResult.english}</p>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => playPronunciation(translationResult.english, 'en')}
                        className="text-ukraine-blue hover:text-ukraine-deep ml-2"
                      >
                        <Volume2 className="h-4 w-4 mr-1" />
                        Play
                      </Button>
                    </div>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </section>

        {/* Main Navigation */}
        <nav className="px-4 mb-6">
          <div className="grid grid-cols-2 gap-4">
            <Link href="/dictionary">
              <Card className="card-shadow hover:shadow-lg transition-all duration-300 group cursor-pointer">
                <CardContent className="p-4 text-center">
                  <div className="w-12 h-12 gradient-ukraine rounded-full flex items-center justify-center mx-auto mb-3 group-hover:scale-110 transition-transform duration-200">
                    <BookOpen className="text-white text-lg" />
                  </div>
                  <h3 className="font-semibold text-gray-900 mb-1">Dictionary</h3>
                  <p className="text-xs text-gray-600">Ukrainian-English</p>
                </CardContent>
              </Card>
            </Link>

            <Link href="/learn">
              <Card className="card-shadow hover:shadow-lg transition-all duration-300 group cursor-pointer">
                <CardContent className="p-4 text-center">
                  <div className="w-12 h-12 gradient-yellow rounded-full flex items-center justify-center mx-auto mb-3 group-hover:scale-110 transition-transform duration-200">
                    <GraduationCap className="text-white text-lg" />
                  </div>
                  <h3 className="font-semibold text-gray-900 mb-1">Learn English</h3>
                  <p className="text-xs text-gray-600">Interactive lessons</p>
                </CardContent>
              </Card>
            </Link>

            <Link href="/history">
              <Card className="card-shadow hover:shadow-lg transition-all duration-300 group cursor-pointer">
                <CardContent className="p-4 text-center">
                  <div className="w-12 h-12 bg-gradient-to-br from-amber-600 to-orange-700 rounded-full flex items-center justify-center mx-auto mb-3 group-hover:scale-110 transition-transform duration-200">
                    <Landmark className="text-white text-lg" />
                  </div>
                  <h3 className="font-semibold text-gray-900 mb-1">Our History</h3>
                  <p className="text-xs text-gray-600">Ukrainian Pioneers</p>
                </CardContent>
              </Card>
            </Link>

            <Link href="/community">
              <Card className="card-shadow hover:shadow-lg transition-all duration-300 group cursor-pointer">
                <CardContent className="p-4 text-center">
                  <div className="w-12 h-12 bg-gradient-to-br from-green-500 to-emerald-600 rounded-full flex items-center justify-center mx-auto mb-3 group-hover:scale-110 transition-transform duration-200">
                    <Users className="text-white text-lg" />
                  </div>
                  <h3 className="font-semibold text-gray-900 mb-1">Community</h3>
                  <p className="text-xs text-gray-600">Resources & Events</p>
                </CardContent>
              </Card>
            </Link>
          </div>
        </nav>

        {/* Historical Timeline Preview */}
        {featuredEvents.length > 0 && (
          <section className="px-4 mb-6 animate-slide-up">
            <Card className="card-shadow overflow-hidden">
              <div className="gradient-ukraine p-4 text-white">
                <h2 className="font-serif font-bold text-xl mb-2">From Galicia to the Prairies</h2>
                <p className="text-ukraine-light text-sm">130+ Years of Ukrainian Manitoba</p>
              </div>

              <CardContent className="p-4">
                <div className="timeline-line">
                  {featuredEvents.map((event) => (
                    <div key={event.id} className="flex mb-6 relative">
                      <div className="w-10 h-10 gradient-yellow rounded-full flex items-center justify-center text-white font-bold text-sm z-10 flex-shrink-0">
                        {event.year}
                      </div>
                      <div className="ml-4 flex-1">
                        <h3 className="font-semibold text-gray-900 mb-1">{event.title}</h3>
                        <p className="text-sm text-gray-600 mb-2">{event.description}</p>
                        <span className="text-xs text-ukraine-blue font-medium">{event.category}</span>
                      </div>
                    </div>
                  ))}
                </div>

                <Link href="/history">
                  <Button className="w-full gradient-ukraine text-white hover:shadow-md transition-all duration-200">
                    <Landmark className="mr-2 h-4 w-4" />
                    Explore Full Timeline
                  </Button>
                </Link>
              </CardContent>
            </Card>
          </section>
        )}

        {/* Community Events Preview */}
        {upcomingEvents.length > 0 && (
          <section className="px-4 mb-6">
            <Card className="card-shadow">
              <div className="p-4 border-b border-gray-100">
                <h2 className="font-serif font-bold text-xl text-gray-900 mb-2">Upcoming Events</h2>
                <p className="text-gray-600 text-sm">Don't miss these community celebrations</p>
              </div>

              <CardContent className="p-4 space-y-4">
                {upcomingEvents.slice(0, 2).map((event) => (
                  <div key={event.id} className="flex items-start space-x-3">
                    <div className="bg-ukraine-yellow rounded-lg px-3 py-2 text-center min-w-fit">
                      <p className="text-xs font-semibold text-gray-800">
                        {event.eventDate ? new Date(event.eventDate).toLocaleDateString('en', { month: 'short' }).toUpperCase() : 'TBD'}
                      </p>
                      <p className="text-lg font-bold text-gray-900">
                        {event.eventDate ? new Date(event.eventDate).getDate() : '?'}
                      </p>
                    </div>
                    <div className="flex-1">
                      <p className="font-medium text-gray-900">{event.name}</p>
                      <p className="text-sm text-gray-600">{event.address}</p>
                      <p className="text-xs text-ukraine-blue mt-1">{event.description}</p>
                    </div>
                  </div>
                ))}

                <Link href="/community">
                  <Button variant="outline" className="w-full border-ukraine-blue text-ukraine-blue hover:bg-ukraine-blue hover:text-white">
                    View All Events
                  </Button>
                </Link>
              </CardContent>
            </Card>
          </section>
        )}
      </main>
    </div>
  );
}
