import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useQuery } from "@tanstack/react-query";
import { DictionaryEntry } from "@shared/schema";
import { Search, Volume2, BookOpen, Star } from "lucide-react";

export default function Dictionary() {
  const [searchQuery, setSearchQuery] = useState("");

  const { data: searchResults = [], isLoading } = useQuery<DictionaryEntry[]>({
    queryKey: ["/api/dictionary/search", { q: searchQuery }],
    enabled: searchQuery.length > 0,
  });

  const { data: allEntries = [] } = useQuery<DictionaryEntry[]>({
    queryKey: ["/api/dictionary"],
    enabled: searchQuery.length === 0,
  });

  const displayEntries = searchQuery.length > 0 ? searchResults : allEntries.slice(0, 20);

  const playPronunciation = (text: string, isUkrainian: boolean) => {
    if ('speechSynthesis' in window) {
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.lang = isUkrainian ? 'uk-UA' : 'en-US';
      speechSynthesis.speak(utterance);
    }
  };

  const categories = Array.from(new Set(allEntries.map(entry => entry.category).filter(Boolean)));

  return (
    <div className="pb-20">
      {/* Header */}
      <header className="gradient-ukraine text-white shadow-lg sticky top-0 z-50">
        <div className="max-w-md mx-auto px-4 py-4">
          <div className="text-center">
            <BookOpen className="mx-auto text-ukraine-yellow text-3xl mb-2" />
            <h1 className="font-serif font-bold text-xl">Ukrainian Dictionary</h1>
            <p className="text-ukraine-light text-sm">Comprehensive Ukrainian-English Dictionary</p>
          </div>
        </div>
      </header>

      <main className="max-w-md mx-auto p-4 space-y-6">
        
        {/* Search */}
        <Card>
          <CardContent className="p-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
              <Input
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search Ukrainian or English..."
                className="pl-10 focus:ring-ukraine"
              />
            </div>
          </CardContent>
        </Card>

        {/* Categories */}
        {searchQuery.length === 0 && categories.length > 0 && (
          <Card>
            <CardHeader>
              <CardTitle className="font-serif text-lg">Browse by Category</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex flex-wrap gap-2">
                {categories.map((category) => (
                  <Badge 
                    key={category} 
                    variant="outline" 
                    className="border-ukraine-blue text-ukraine-blue hover:bg-ukraine-blue hover:text-white cursor-pointer"
                    onClick={() => setSearchQuery(category || "")}
                  >
                    {category}
                  </Badge>
                ))}
              </div>
            </CardContent>
          </Card>
        )}

        {/* Dictionary Entries */}
        <div className="space-y-4">
          {isLoading && (
            <Card>
              <CardContent className="p-4 text-center">
                <p className="text-gray-500">Searching dictionary...</p>
              </CardContent>
            </Card>
          )}

          {displayEntries.length === 0 && !isLoading && searchQuery.length > 0 && (
            <Card>
              <CardContent className="p-4 text-center">
                <p className="text-gray-500">No entries found for "{searchQuery}"</p>
                <p className="text-sm text-gray-400 mt-2">Try searching for a different word</p>
              </CardContent>
            </Card>
          )}

          {displayEntries.map((entry) => (
            <Card key={entry.id} className="card-shadow hover:shadow-lg transition-shadow">
              <CardContent className="p-4">
                <div className="space-y-3">
                  {/* Ukrainian Word */}
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <h3 className="font-serif font-bold text-xl text-ukraine-blue">
                        {entry.ukrainianWord}
                      </h3>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => playPronunciation(entry.ukrainianWord, true)}
                        className="text-ukraine-blue hover:text-ukraine-deep"
                      >
                        <Volume2 className="h-4 w-4" />
                      </Button>
                    </div>
                    <Button variant="ghost" size="sm" className="text-gray-400 hover:text-yellow-500">
                      <Star className="h-4 w-4" />
                    </Button>
                  </div>

                  {/* Pronunciation */}
                  {entry.pronunciation && (
                    <p className="text-sm text-gray-600 italic">
                      /{entry.pronunciation}/
                    </p>
                  )}

                  {/* English Translation */}
                  <div className="flex items-center space-x-2">
                    <p className="text-lg font-medium text-gray-900 flex-1">
                      {entry.englishTranslation}
                    </p>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => playPronunciation(entry.englishTranslation, false)}
                      className="text-ukraine-blue hover:text-ukraine-deep"
                    >
                      <Volume2 className="h-4 w-4" />
                    </Button>
                  </div>

                  {/* Part of Speech */}
                  {entry.partOfSpeech && (
                    <Badge variant="secondary" className="text-xs">
                      {entry.partOfSpeech}
                    </Badge>
                  )}

                  {/* Examples */}
                  {entry.examples && entry.examples.length > 0 && (
                    <div className="border-t border-gray-100 pt-3 mt-3">
                      <p className="text-sm font-medium text-gray-700 mb-2">Examples:</p>
                      {entry.examples.map((example, index) => (
                        <div key={index} className="bg-gray-50 rounded-lg p-3 mb-2">
                          <p className="text-sm text-ukraine-blue mb-1">{example.ukrainian}</p>
                          <p className="text-sm text-gray-600">{example.english}</p>
                        </div>
                      ))}
                    </div>
                  )}

                  {/* Category */}
                  {entry.category && (
                    <div className="flex justify-end">
                      <Badge 
                        variant="outline" 
                        className="text-xs border-ukraine-blue text-ukraine-blue"
                      >
                        {entry.category}
                      </Badge>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Load More */}
        {displayEntries.length >= 20 && searchQuery.length === 0 && (
          <Card>
            <CardContent className="p-4 text-center">
              <Button variant="outline" className="border-ukraine-blue text-ukraine-blue hover:bg-ukraine-blue hover:text-white">
                Load More Entries
              </Button>
            </CardContent>
          </Card>
        )}
      </main>
    </div>
  );
}
