import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { useQuery } from "@tanstack/react-query";
import { LearningModule } from "@shared/schema";
import { 
  GraduationCap, 
  Clock, 
  Volume2, 
  Mic, 
  Award, 
  CheckCircle,
  Circle,
  ChevronRight
} from "lucide-react";

export default function Learn() {
  const [selectedModule, setSelectedModule] = useState<string | null>(null);

  const { data: learningModules = [] } = useQuery<LearningModule[]>({
    queryKey: ["/api/learning/modules"],
  });

  // Mock user progress - in real app this would come from user data
  const userProgress = {
    totalProgress: 68,
    completedLessons: ['daily-conversations-1', 'daily-conversations-2', 'workplace-english-1'],
    currentModule: 'workplace-english'
  };

  const getModuleProgress = (module: LearningModule) => {
    if (!module.content?.lessons) return 0;
    const completedLessons = module.content.lessons.filter((lesson: any) => lesson.completed).length;
    return Math.round((completedLessons / module.content.lessons.length) * 100);
  };

  const getModuleStatus = (module: LearningModule) => {
    const progress = getModuleProgress(module);
    if (progress === 100) return 'completed';
    if (progress > 0) return 'in-progress';
    return 'new';
  };

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty.toLowerCase()) {
      case 'beginner': return 'bg-green-100 text-green-700';
      case 'intermediate': return 'bg-yellow-100 text-yellow-700';
      case 'advanced': return 'bg-red-100 text-red-700';
      default: return 'bg-gray-100 text-gray-700';
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'completed':
        return <Badge className="bg-green-100 text-green-700">Completed</Badge>;
      case 'in-progress':
        return <Badge className="bg-ukraine-blue text-white">In Progress</Badge>;
      default:
        return <Badge variant="outline">New</Badge>;
    }
  };

  return (
    <div className="pb-20">
      {/* Header */}
      <header className="gradient-ukraine text-white shadow-lg sticky top-0 z-50">
        <div className="max-w-md mx-auto px-4 py-4">
          <div className="text-center">
            <GraduationCap className="mx-auto text-ukraine-yellow text-3xl mb-2" />
            <h1 className="font-serif font-bold text-xl">Learn English Your Way</h1>
            <p className="text-ukraine-light text-sm">Interactive ESL for Ukrainian speakers</p>
          </div>
        </div>
      </header>

      <main className="max-w-md mx-auto p-4 space-y-6">
        
        {/* Progress Overview */}
        <Card className="card-shadow">
          <CardContent className="p-4">
            <div className="bg-gradient-to-r from-green-50 to-emerald-50 rounded-lg p-4">
              <div className="flex items-center justify-between mb-3">
                <h3 className="font-serif font-semibold text-gray-900">Overall Progress</h3>
                <span className="text-lg font-bold text-emerald-600">{userProgress.totalProgress}%</span>
              </div>
              <Progress value={userProgress.totalProgress} className="mb-2" />
              <p className="text-sm text-gray-600">
                {userProgress.completedLessons.length} lessons completed this week
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Learning Modules */}
        <div className="space-y-4">
          <h2 className="font-serif font-bold text-xl text-gray-900">Learning Modules</h2>
          
          {learningModules.map((module) => {
            const progress = getModuleProgress(module);
            const status = getModuleStatus(module);
            const isCurrentModule = userProgress.currentModule === module.id;
            
            return (
              <Card 
                key={module.id} 
                className={`card-shadow hover:shadow-lg transition-all duration-300 cursor-pointer ${
                  isCurrentModule ? 'ring-2 ring-ukraine-blue bg-ukraine-light/10' : ''
                }`}
                onClick={() => setSelectedModule(module.id)}
              >
                <CardContent className="p-4">
                  <div className="space-y-3">
                    {/* Header */}
                    <div className="flex items-center justify-between">
                      <h3 className="font-semibold text-gray-900 flex-1">{module.title}</h3>
                      <div className="flex items-center space-x-2">
                        {getStatusBadge(status)}
                        <ChevronRight className="h-4 w-4 text-gray-400" />
                      </div>
                    </div>

                    {/* Description */}
                    <p className="text-sm text-gray-600">{module.description}</p>

                    {/* Module Features */}
                    <div className="flex items-center space-x-4 text-xs text-gray-500">
                      <div className="flex items-center">
                        <Clock className="h-3 w-3 mr-1" />
                        {module.estimatedTime} min
                      </div>
                      {module.hasAudio && (
                        <div className="flex items-center">
                          <Volume2 className="h-3 w-3 mr-1" />
                          Audio
                        </div>
                      )}
                      {module.hasVoicePractice && (
                        <div className="flex items-center">
                          <Mic className="h-3 w-3 mr-1" />
                          Voice Practice
                        </div>
                      )}
                      {module.hasCertificate && (
                        <div className="flex items-center">
                          <Award className="h-3 w-3 mr-1" />
                          Certificate
                        </div>
                      )}
                    </div>

                    {/* Difficulty Badge */}
                    <div className="flex items-center justify-between">
                      <Badge className={getDifficultyColor(module.difficulty)}>
                        {module.difficulty}
                      </Badge>
                      
                      {/* Progress Bar */}
                      {progress > 0 && (
                        <div className="flex items-center space-x-2">
                          <div className="w-20 bg-gray-200 rounded-full h-1.5">
                            <div 
                              className="bg-ukraine-blue h-1.5 rounded-full transition-all duration-300" 
                              style={{ width: `${progress}%` }}
                            />
                          </div>
                          <span className="text-xs text-gray-500">{progress}%</span>
                        </div>
                      )}
                    </div>

                    {/* Lessons Preview */}
                    {module.content?.lessons && (
                      <div className="border-t border-gray-100 pt-3">
                        <p className="text-xs font-medium text-gray-600 mb-2">Lessons:</p>
                        <div className="space-y-1">
                          {module.content.lessons.slice(0, 3).map((lesson: any) => (
                            <div key={lesson.id} className="flex items-center space-x-2 text-xs">
                              {lesson.completed ? (
                                <CheckCircle className="h-3 w-3 text-green-500" />
                              ) : (
                                <Circle className="h-3 w-3 text-gray-400" />
                              )}
                              <span className={lesson.completed ? "text-green-700" : "text-gray-600"}>
                                {lesson.title}
                              </span>
                            </div>
                          ))}
                          {module.content.lessons.length > 3 && (
                            <p className="text-xs text-gray-500">
                              +{module.content.lessons.length - 3} more lessons
                            </p>
                          )}
                        </div>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {/* Quick Access Features */}
        <Card className="card-shadow">
          <CardHeader>
            <CardTitle className="font-serif">Quick Practice</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 gap-3">
              <Button variant="outline" className="border-ukraine-blue text-ukraine-blue hover:bg-ukraine-blue hover:text-white">
                <Mic className="mr-2 h-4 w-4" />
                Voice Practice
              </Button>
              <Button variant="outline" className="border-ukraine-blue text-ukraine-blue hover:bg-ukraine-blue hover:text-white">
                <Volume2 className="mr-2 h-4 w-4" />
                Pronunciation
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Study Goals */}
        <Card className="card-shadow">
          <CardHeader>
            <CardTitle className="font-serif">Study Goals</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-sm">Daily practice</span>
                <div className="flex items-center space-x-1">
                  <CheckCircle className="h-4 w-4 text-green-500" />
                  <span className="text-sm text-green-600">Completed</span>
                </div>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm">Weekly lesson goal</span>
                <div className="flex items-center space-x-2">
                  <Progress value={75} className="w-16" />
                  <span className="text-sm text-ukraine-blue">3/4</span>
                </div>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm">Monthly certificate</span>
                <div className="flex items-center space-x-1">
                  <Circle className="h-4 w-4 text-gray-400" />
                  <span className="text-sm text-gray-500">In progress</span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </main>
    </div>
  );
}
