import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useQuery } from "@tanstack/react-query";
import { CommunityResource } from "@shared/schema";
import { 
  Users, 
  MapPin, 
  Phone, 
  Globe, 
  Calendar,
  Building,
  Heart,
  ExternalLink,
  Clock
} from "lucide-react";

export default function Community() {
  const { data: allResources = [] } = useQuery<CommunityResource[]>({
    queryKey: ["/api/community/resources"],
  });

  const { data: upcomingEvents = [] } = useQuery<CommunityResource[]>({
    queryKey: ["/api/community/events"],
  });

  const culturalCenters = allResources.filter(r => r.type === 'cultural_center');
  const services = allResources.filter(r => r.type === 'service');

  const formatEventDate = (date: Date | string) => {
    const eventDate = new Date(date);
    return new Intl.DateTimeFormat('en', {
      month: 'short',
      day: 'numeric',
      year: 'numeric'
    }).format(eventDate);
  };

  const getDaysUntilEvent = (eventDate: Date | string) => {
    const now = new Date();
    const event = new Date(eventDate);
    const diffTime = event.getTime() - now.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return diffDays;
  };

  return (
    <div className="pb-20">
      {/* Header */}
      <header className="gradient-ukraine text-white shadow-lg sticky top-0 z-50">
        <div className="max-w-md mx-auto px-4 py-4">
          <div className="text-center">
            <Users className="mx-auto text-ukraine-yellow text-3xl mb-2" />
            <h1 className="font-serif font-bold text-xl">Your Ukrainian Manitoba Community</h1>
            <p className="text-ukraine-light text-sm">Resources, events, and connections</p>
          </div>
        </div>
      </header>

      <main className="max-w-md mx-auto p-4 space-y-6">
        
        {/* Upcoming Events */}
        {upcomingEvents.length > 0 && (
          <Card className="card-shadow">
            <CardHeader className="pb-4">
              <CardTitle className="font-serif flex items-center">
                <Calendar className="mr-2 h-5 w-5 text-ukraine-blue" />
                Upcoming Events
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {upcomingEvents.map((event) => {
                const daysUntil = event.eventDate ? getDaysUntilEvent(event.eventDate) : null;
                
                return (
                  <div key={event.id} className="bg-gradient-to-r from-orange-50 to-amber-50 rounded-lg p-4">
                    <div className="flex items-start space-x-3">
                      <div className="bg-ukraine-yellow rounded-lg px-3 py-2 text-center min-w-fit">
                        <p className="text-xs font-semibold text-gray-800">
                          {event.eventDate ? 
                            new Date(event.eventDate).toLocaleDateString('en', { month: 'short' }).toUpperCase() 
                            : 'TBD'
                          }
                        </p>
                        <p className="text-lg font-bold text-gray-900">
                          {event.eventDate ? new Date(event.eventDate).getDate() : '?'}
                        </p>
                      </div>
                      <div className="flex-1 space-y-2">
                        <div>
                          <h3 className="font-semibold text-gray-900">{event.name}</h3>
                          {event.address && (
                            <p className="text-sm text-gray-600 flex items-center">
                              <MapPin className="h-3 w-3 mr-1" />
                              {event.address}
                            </p>
                          )}
                        </div>
                        
                        <p className="text-xs text-gray-700">{event.description}</p>
                        
                        <div className="flex items-center justify-between">
                          {daysUntil !== null && (
                            <Badge 
                              variant={daysUntil <= 7 ? "default" : "outline"}
                              className={daysUntil <= 7 ? "bg-orange-500 text-white" : ""}
                            >
                              {daysUntil === 0 ? "Today" : 
                               daysUntil === 1 ? "Tomorrow" : 
                               `${daysUntil} days`}
                            </Badge>
                          )}
                          <Button variant="outline" size="sm">
                            Learn More
                          </Button>
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </CardContent>
          </Card>
        )}

        {/* Cultural Centers */}
        <Card className="card-shadow">
          <CardHeader className="pb-4">
            <CardTitle className="font-serif flex items-center">
              <Building className="mr-2 h-5 w-5 text-ukraine-blue" />
              Cultural Centers
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {culturalCenters.map((center) => (
              <div key={center.id} className="bg-gradient-to-r from-ukraine-light/20 to-blue-50 rounded-lg p-4">
                <div className="space-y-3">
                  <div>
                    <h3 className="font-semibold text-gray-900">{center.name}</h3>
                    {center.address && (
                      <p className="text-sm text-gray-600 flex items-center">
                        <MapPin className="h-3 w-3 mr-1" />
                        {center.address}
                      </p>
                    )}
                  </div>
                  
                  {center.description && (
                    <p className="text-xs text-ukraine-blue">{center.description}</p>
                  )}
                  
                  <div className="flex items-center space-x-2">
                    {center.phone && (
                      <Button variant="outline" size="sm" className="text-xs">
                        <Phone className="h-3 w-3 mr-1" />
                        Call
                      </Button>
                    )}
                    {center.website && (
                      <Button variant="outline" size="sm" className="text-xs">
                        <Globe className="h-3 w-3 mr-1" />
                        Website
                      </Button>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>

        {/* Community Services */}
        <Card className="card-shadow">
          <CardHeader className="pb-4">
            <CardTitle className="font-serif flex items-center">
              <Heart className="mr-2 h-5 w-5 text-ukraine-blue" />
              Community Services
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {services.map((service) => (
              <div key={service.id} className="border border-gray-100 rounded-lg p-4">
                <div className="space-y-3">
                  <div>
                    <h3 className="font-semibold text-gray-900">{service.name}</h3>
                    {service.address && (
                      <p className="text-sm text-gray-600 flex items-center">
                        <MapPin className="h-3 w-3 mr-1" />
                        {service.address}
                      </p>
                    )}
                  </div>
                  
                  {service.description && (
                    <p className="text-sm text-gray-700">{service.description}</p>
                  )}
                  
                  <div className="flex items-center space-x-2">
                    {service.phone && (
                      <Button variant="outline" size="sm" className="text-xs">
                        <Phone className="h-3 w-3 mr-1" />
                        {service.phone}
                      </Button>
                    )}
                    {service.website && (
                      <Button variant="outline" size="sm" className="text-xs">
                        <ExternalLink className="h-3 w-3 mr-1" />
                        Visit Site
                      </Button>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>

        {/* Quick Access */}
        <Card className="card-shadow">
          <CardHeader className="pb-4">
            <CardTitle className="font-serif">Quick Access</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 gap-3">
              <Button variant="outline" className="border-green-500 text-green-600 hover:bg-green-50">
                <Phone className="mr-2 h-4 w-4" />
                Emergency
              </Button>
              <Button variant="outline" className="border-blue-500 text-blue-600 hover:bg-blue-50">
                <MapPin className="mr-2 h-4 w-4" />
                Manitoba Guide
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Community Stats */}
        <Card className="card-shadow">
          <CardContent className="p-4">
            <h3 className="font-serif font-semibold text-gray-900 mb-4 text-center">
              Ukrainian Manitoba Today
            </h3>
            <div className="grid grid-cols-2 gap-4 text-center">
              <div>
                <p className="text-2xl font-bold text-ukraine-blue font-serif">9%</p>
                <p className="text-xs text-gray-600">of Ukrainian-Canadians live in Winnipeg</p>
              </div>
              <div>
                <p className="text-2xl font-bold text-ukraine-blue font-serif">13%</p>
                <p className="text-xs text-gray-600">of Ukrainian-Canadians live in Manitoba</p>
              </div>
            </div>
            <div className="mt-4 p-3 bg-ukraine-light/20 rounded-lg">
              <p className="text-xs text-gray-700 text-center">
                Manitoba has a larger proportion of Ukrainian-Canadians compared to the national average, 
                maintaining our strong cultural presence since 1891.
              </p>
            </div>
          </CardContent>
        </Card>
      </main>
    </div>
  );
}
