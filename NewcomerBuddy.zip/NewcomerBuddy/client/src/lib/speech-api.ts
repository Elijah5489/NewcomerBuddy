export interface SpeechOptions {
  lang?: 'uk-UA' | 'en-US' | string;
  rate?: number;
  pitch?: number;
  volume?: number;
}

export interface SpeechApiReturn {
  speak: (text: string, options?: SpeechOptions) => Promise<void>;
  stop: () => void;
  isSupported: boolean;
  isSpeaking: boolean;
  getVoices: () => SpeechSynthesisVoice[];
  getUkrainianVoices: () => SpeechSynthesisVoice[];
  getEnglishVoices: () => SpeechSynthesisVoice[];
}

class SpeechApi {
  private synthesis: SpeechSynthesis;
  private currentUtterance: SpeechSynthesisUtterance | null = null;
  private voices: SpeechSynthesisVoice[] = [];
  private _isSpeaking = false;

  constructor() {
    this.synthesis = window.speechSynthesis;
    this.loadVoices();
    
    // Load voices when they become available
    if (this.synthesis.onvoiceschanged !== undefined) {
      this.synthesis.onvoiceschanged = () => {
        this.loadVoices();
      };
    }
  }

  private loadVoices() {
    this.voices = this.synthesis.getVoices();
  }

  get isSupported(): boolean {
    return 'speechSynthesis' in window;
  }

  get isSpeaking(): boolean {
    return this._isSpeaking || this.synthesis.speaking;
  }

  getVoices(): SpeechSynthesisVoice[] {
    return this.voices;
  }

  getUkrainianVoices(): SpeechSynthesisVoice[] {
    return this.voices.filter(voice => 
      voice.lang.startsWith('uk') || 
      voice.lang.toLowerCase().includes('ukrain')
    );
  }

  getEnglishVoices(): SpeechSynthesisVoice[] {
    return this.voices.filter(voice => 
      voice.lang.startsWith('en-US') || 
      voice.lang.startsWith('en-CA') ||
      voice.lang.startsWith('en-GB')
    );
  }

  private getBestVoice(lang: string): SpeechSynthesisVoice | null {
    // First try to find exact language match
    let voice = this.voices.find(v => v.lang === lang);
    
    if (!voice) {
      // Try to find language family match (e.g., 'en' for 'en-US')
      const langFamily = lang.split('-')[0];
      voice = this.voices.find(v => v.lang.startsWith(langFamily));
    }

    if (!voice && lang.startsWith('uk')) {
      // For Ukrainian, try to find any Slavic voice as fallback
      voice = this.voices.find(v => 
        v.lang.startsWith('ru') || 
        v.lang.startsWith('pl') || 
        v.lang.startsWith('cs')
      );
    }

    return voice || null;
  }

  async speak(text: string, options: SpeechOptions = {}): Promise<void> {
    if (!this.isSupported) {
      throw new Error('Speech synthesis is not supported in this browser');
    }

    if (!text.trim()) {
      throw new Error('No text provided for speech synthesis');
    }

    // Stop any current speech
    this.stop();

    return new Promise((resolve, reject) => {
      const utterance = new SpeechSynthesisUtterance(text);
      
      // Set language
      const lang = options.lang || 'en-US';
      utterance.lang = lang;

      // Try to find the best voice for the language
      const voice = this.getBestVoice(lang);
      if (voice) {
        utterance.voice = voice;
      }

      // Set speech parameters
      utterance.rate = options.rate || 0.9; // Slightly slower for clarity
      utterance.pitch = options.pitch || 1.0;
      utterance.volume = options.volume || 0.8;

      // Event handlers
      utterance.onstart = () => {
        this._isSpeaking = true;
      };

      utterance.onend = () => {
        this._isSpeaking = false;
        this.currentUtterance = null;
        resolve();
      };

      utterance.onerror = (event) => {
        this._isSpeaking = false;
        this.currentUtterance = null;
        reject(new Error(`Speech synthesis error: ${event.error}`));
      };

      // Store current utterance
      this.currentUtterance = utterance;

      // Start speaking
      try {
        this.synthesis.speak(utterance);
      } catch (error) {
        this._isSpeaking = false;
        this.currentUtterance = null;
        reject(error);
      }
    });
  }

  stop(): void {
    if (this.synthesis.speaking || this.synthesis.pending) {
      this.synthesis.cancel();
    }
    this._isSpeaking = false;
    this.currentUtterance = null;
  }

  // Convenience methods for specific languages
  async speakUkrainian(text: string, options: Omit<SpeechOptions, 'lang'> = {}): Promise<void> {
    return this.speak(text, { ...options, lang: 'uk-UA' });
  }

  async speakEnglish(text: string, options: Omit<SpeechOptions, 'lang'> = {}): Promise<void> {
    return this.speak(text, { ...options, lang: 'en-US' });
  }

  // Method to check if specific language is available
  isLanguageSupported(lang: string): boolean {
    return this.getBestVoice(lang) !== null;
  }

  // Method to get language support info
  getLanguageSupport(): { ukrainian: boolean; english: boolean } {
    return {
      ukrainian: this.isLanguageSupported('uk-UA'),
      english: this.isLanguageSupported('en-US')
    };
  }
}

// Create singleton instance
const speechApi = new SpeechApi();

// Export both the class and instance
export { SpeechApi };
export default speechApi;

// Hook for React components
export function useSpeechApi(): SpeechApiReturn {
  return {
    speak: speechApi.speak.bind(speechApi),
    stop: speechApi.stop.bind(speechApi),
    isSupported: speechApi.isSupported,
    isSpeaking: speechApi.isSpeaking,
    getVoices: speechApi.getVoices.bind(speechApi),
    getUkrainianVoices: speechApi.getUkrainianVoices.bind(speechApi),
    getEnglishVoices: speechApi.getEnglishVoices.bind(speechApi)
  };
}

// Utility functions for common use cases
export const speechUtils = {
  // Play pronunciation with feedback
  async playPronunciation(text: string, lang: 'uk' | 'en' = 'en'): Promise<void> {
    const language = lang === 'uk' ? 'uk-UA' : 'en-US';
    return speechApi.speak(text, { lang: language, rate: 0.8 });
  },

  // Play translation result
  async playTranslation(text: string, lang: 'uk' | 'en'): Promise<void> {
    const language = lang === 'uk' ? 'uk-UA' : 'en-US';
    return speechApi.speak(text, { lang: language });
  },

  // Stop all speech
  stopAll(): void {
    speechApi.stop();
  },

  // Check browser support
  checkSupport(): { supported: boolean; languages: { ukrainian: boolean; english: boolean } } {
    return {
      supported: speechApi.isSupported,
      languages: speechApi.getLanguageSupport()
    };
  }
};
